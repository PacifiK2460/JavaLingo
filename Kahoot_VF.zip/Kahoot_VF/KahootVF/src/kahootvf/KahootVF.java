/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kahootvf;

/**
 *
 * @author 177557
 */
//public class KahootVF {
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KahootVF extends JFrame {
    private JLabel oracionLabel;
    private JButton[] botones;
   
    //Eliminar la palabra y poner _____ donde deba faltar la palabra
    private String[] oraciones = {"Tá muito quente aqui, eu 'to morrendo de calor","eu james eu quero uma salada de fruta","O menor de minas preocupações","Um homem sem paciência é como uma lâmpada sem azeite","É na dificuldade que se prova a amizade","E como tudo na vida, dê tempo ao tempo e ele encarregar-se hà de resolver os problemas","Quem sabe amar sabe castgar","Quem não pouca a agua ou a lenha, não poupa nada que tenha","As nossas desgraças entram sempre por portas que nós abrimos","Em dinheiro vivo","Um passo à frente e você não está mais no mesmo lugar","Obrigado por ser sempre o meu arco-íris depois da tempestade","Devagar se vai ao longe","Suporta-se com paciência a cólica dos outros","Cão que ladra não morde","Em boca fechada não entra mosca","A minha xota é o incêndio e seu pau é o extintor","Quem vê caras não vê corações","Quem não arrisca não petisca","É melhor prevenir do que remediar"};

    private String[] palabras = {"morrendo","salada", "preocupações", "paciência", "amizade", "encarregar","castgar","lenha","desgraças","dinheiro","você","Obrigado","Devagar","cólica","Cão","fechada","xota","corações","arrisca","melhor"};

    private String[][] opciones = {{"muriendo", "morrendo", "dying", "morrido"}, {"salada", "salad", "salade", "salado"}, {"preocupao", "préoccupations", "preocupações", "preocupations"}, {"patience", "paciência", "paciencia", "Anliegen"},{"amizade","amistades","friendship","Freundschaften"},{"charge","cargar","encarrgar","encarregar"},{"punishment","castigar","punir","castgar"},{"madera","lenha","brennholz","leña"},{"desgraças","unglück","desgraçias","desgracias"},{"dinero","geld","dinheiro","money"},{"vocês","you","vos","você"},{"Obrigado","Agradecido","Thanks","Arigatou"},{"Slow","Devagar","Divagar","Despacio"},{"colicaos","cólica","colicos","cólico"},{"Solovino","Perriño","Cão","Dog"},{"fechada","cerrao","closed","fechado"},{"mamão","papaya","pussy","xota"},{"coraçõnes","colacaos","corações","corazones"},{"arriscao","arrisca","riesgo","danger"},{"minus", "melhor", "melor", "menor"}};
    
    private int oracionActual = 0;
    private int tiempoRestante = 15;
    private Timer temporizador;

    public KahootVF() {
        super("Juego de Oraciones");
        setLayout(new BorderLayout());

        // Crea la etiqueta para mostrar la oración actual
        oracionLabel = new JLabel(oraciones[oracionActual], JLabel.CENTER);
        oracionLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        add(oracionLabel, BorderLayout.CENTER);

        // Crea los botones para las opciones de palabras
        botones = new JButton[4];
        for (int i = 0; i < 4; i++) {
            botones[i] = new JButton(opciones[oracionActual][i]);
            botones[i].setFont(new Font("Arial", Font.PLAIN, 18));
            botones[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    verificarRespuesta(((JButton)e.getSource()).getText());
                }
            });
        }

        // Agrega los botones a un panel y lo coloca en la parte inferior
        JPanel panelBotones = new JPanel(new GridLayout(1, 4));
        for (int i = 0; i < 4; i++) {
            panelBotones.add(botones[i]);
        }
        add(panelBotones, BorderLayout.SOUTH);

        // Crea el temporizador y lo coloca en la parte superior
        JLabel temporizadorLabel = new JLabel("Tiempo restante: " + tiempoRestante, JLabel.CENTER);
        temporizadorLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        add(temporizadorLabel, BorderLayout.NORTH);
        temporizador = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tiempoRestante--;
                temporizadorLabel.setText("Tiempo restante: " + tiempoRestante);
                if (tiempoRestante == 0) {
                    avanzarOracion();
                }
            }
        });
        temporizador.start();

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void verificarRespuesta(String respuesta) {
        if (respuesta.equals(palabras[oracionActual])) {
            avanzarOracion();
        } else {
            tiempoRestante -= 3;
            if (tiempoRestante < 0) {
                tiempoRestante = 0;
            }
        }
    }

    private void avanzarOracion() {
        oracionActual++;
        if (oracionActual < oraciones.length && oracionActual < 5) {
            oracionLabel.setText(oraciones[oracionActual]);
            for (int i = 0; i < 4; i++) {
                botones[i].setText(opciones[oracionActual][i]);
            }
            tiempoRestante = 15;
            temporizador.restart();
        } else {
            JOptionPane.showMessageDialog(this, "¡Juego terminado!");
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        KahootVF juego = new KahootVF();
    }
}

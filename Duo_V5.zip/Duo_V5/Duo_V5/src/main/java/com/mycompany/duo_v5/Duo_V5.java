/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.duo_v5;

/**
 *
 * @author 177557
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Duo_V5 extends JFrame {
    private JLabel oracionLabel;
    private JTextField[] camposTexto;
    private String[] oraciones = {"Anoche me ______ un helado.", "Mi hermano mayor es muy ______.", "Me gusta comer pizza con ______.", "El sol está muy ______ hoy.", "Mi película favorita es ______ Wars."};
    private String[][] opciones = {{"comí", "komi", "coní", "comer"}, {"alto", "altor", "altoz", "altos"}, {"piña", "pina", "pinya", "piñia"}, {"caliente", "calienta", "calenté", "calienti"}, {"Star", "Starz", "Stor", "Stir"}};
    private int oracionActual = 0;
    private int intentosRestantes = 5;

    public Duo_V5() {
        super("Juego de Acomodar Palabras");
        setLayout(new BorderLayout());

        // Crea la etiqueta para mostrar la oración actual
        oracionLabel = new JLabel(oraciones[oracionActual], JLabel.CENTER);
        oracionLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        add(oracionLabel, BorderLayout.NORTH);

        // Crea los campos de texto para las palabras
        camposTexto = new JTextField[5];
        for (int i = 0; i < 5; i++) {
            camposTexto[i] = new JTextField(10);
            camposTexto[i].setFont(new Font("Arial", Font.PLAIN, 18));
            add(camposTexto[i], BorderLayout.CENTER);
        }

        // Crea los botones para las opciones de palabras
        JPanel panelBotones = new JPanel(new GridLayout(1, 4));
        for (int i = 0; i < 4; i++) {
            JButton botonOpcion = new JButton(opciones[oracionActual][i]);
            botonOpcion.setFont(new Font("Arial", Font.PLAIN, 18));
            botonOpcion.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    verificarRespuesta(((JButton)e.getSource()).getText());
                }
            });
            panelBotones.add(botonOpcion);
        }
        add(panelBotones, BorderLayout.SOUTH);

        setSize(800, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void verificarRespuesta(String respuesta) {
        if (respuesta.equals(opciones[oracionActual][4])) {
            JOptionPane.showMessageDialog(this, "¡Respuesta correcta!");
            avanzarOracion();
        } else {
            intentosRestantes--;
            if (intentosRestantes == 0) {
                JOptionPane.showMessageDialog(this, "¡Juego terminado!");
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(this, "Respuesta incorrecta. Intentos restantes: " + intentosRestantes);
            }
        }
    }

    private void avanzarOracion() {
        oracionActual++;
        if (oracionActual < oraciones.length && intentosRestantes > 0) {
            oracionLabel.setText(oraciones[oracionActual]);
            for (int i = 0; i < 5; i++) {
                camposTexto[i].setText("");
            }
            for (int i = 0; i < 4; i++) {
                JButton botonOpcion = (JButton)((JPanel)getContentPane().getComponent(1)).getComponent(i);
                botonOpcion.setText(opciones[oracionActual][i]);
            }
        } else {
            JOptionPane.showMessageDialog(this, "¡Juego terminado!");
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        Duo_V5 juego = new Duo_V5();
    }
}
